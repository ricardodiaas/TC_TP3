# python-fuse #

[![Build Status](https://travis-ci.org/libfuse/python-fuse.svg?branch=master)](https://travis-ci.org/libfuse/python-fuse)

This is a Python interface to libfuse
(https://github.com/libfuse/libfuse).

* The API is described in ``README.new_fusepy_api``. It's an
  informative description, not a reference. Apart from that, see the
  examples and the actual code.

* Project home page is https://github.com/libfuse/python-fuse
